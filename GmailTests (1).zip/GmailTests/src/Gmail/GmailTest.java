package Gmail;


import static org.testng.AssertJUnit.assertFalse;
import static org.testng.AssertJUnit.assertTrue;
import java.io.*;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.openqa.selenium.firefox.*;

public class GmailTest {
	private User userTest;
	private FirefoxDriver driver;
	private GmailHandler gmail;
	
  @BeforeTest
  public void beforeTest() throws IOException {
	  userTest 	= new User("C:\\Temp\\user.txt");
	  driver 	= new FirefoxDriver();
	  gmail 	= new GmailHandler(driver);
  }
  
  @Test(description="The system should be able to logging into Gmail")
  public void Test001(){
	  gmail.GmailLogging(userTest.getUserName(), userTest.getPassword());
	  assertTrue( driver.getTitle().startsWith("Inbox"));
	  gmail.LoggingOut();
  }
  
  @Test(description="The system should be able to send an mail. Checks that the first unread email has been sent by me")
  public void Test002(){
	  gmail.GmailLogging(userTest.getUserName(), userTest.getPassword());
	  
	  String subject = "[Test002] Subject";
	  gmail.SendMail(userTest.getUserName(), subject);

	  assertTrue(gmail.getFirstUnreadMail().getText().startsWith(subject));
	  gmail.LoggingOut();
  }
  
  @Test(description="The system should be able to delete an email")
  public void Test003(){
	  gmail.GmailLogging(userTest.getUserName(), userTest.getPassword());
	  
	  String subject = "[Test003] Subject";
	  gmail.SendMail(userTest.getUserName(), subject);
	  gmail.deleteFirstUnreadMail();

	  assertFalse(gmail.getFirstUnreadMail().getText().startsWith(subject));
	  gmail.LoggingOut();
  }  

  @AfterTest
  public void afterTest() {
	  driver.close();
  }


}
