package Gmail;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class GmailHandler {
	private FirefoxDriver driver;
	
	public GmailHandler(FirefoxDriver driver){
		this.driver = driver;
	}
	
	public void GmailLogging(String user, String pass){
		driver.get("http://www.gmail.com");
        
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        
        driver.findElement(By.id("Email")).sendKeys(user);
        driver.findElement(By.id("Passwd")).sendKeys(pass);
        driver.findElement(By.id("signIn")).click();
        
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.titleContains("Inbox"));
	}
	
	public void LoggingOut(){
        driver.get("https://mail.google.com/mail/u/0/?logout");
		WebDriverWait wait = new WebDriverWait(driver, 100);
	    wait.until(ExpectedConditions.titleContains("Gmail:"));
	}
	
	public void SendMail(String dest, String subject){
        WebElement composeMail = driver.findElement(By.cssSelector("div[class='T-I J-J5-Ji T-I-KE L3']"));
        composeMail.click();      
        
                  
        WebElement to = driver.findElement(By.cssSelector("textarea[class='dK nr']"));
        to.sendKeys(dest); 
        
        WebElement subjectField = driver.findElement(By.cssSelector("input[class='ez nr']"));
        subjectField.sendKeys(subject);
      
        WebElement sendButton = driver.findElement(By.cssSelector("div[class='T-I J-J5-Ji Bq nS T-I-KE L3']>b"));
        sendButton.click();
        
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.titleContains("Inbox"));
        driver.get("http://www.gmail.com");
        wait.until(ExpectedConditions.titleContains("Inbox"));
	}
	
	public WebElement getFirstUnreadMail(){
		return driver.findElement(By.xpath("//*[@id=':rr']/div/div/div[4]/div[2]/div[2]/div/table/tbody/tr/td[6]/div"));
	}
	
	public void deleteFirstUnreadMail(){
		WebElement firstMail = getFirstUnreadMail();
		firstMail.click();
		WebElement borrar = driver.findElement(By.xpath("//*[@id=':ro']/div[2]/div/div/div[2]/div[3]/div/div"));
        borrar.click();
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.titleContains("Inbox"));
	}
}
