package Gmail;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;


public class User {
	private String userName;
	private String password;
	
	public User(String filename){
		
			try {
				File archivo = new File (filename);
				FileReader fr = new FileReader (archivo);
				BufferedReader br = new BufferedReader(fr);
				
				userName = br.readLine();
				password = br.readLine();
				br.close();
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
